"""Immich to GitHub sync tool."""

__version__ = "0.1.0"
